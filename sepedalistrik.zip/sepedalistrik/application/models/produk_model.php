<?php
class Produk_model extends CI_Model{
function get_produk(){
$result = $this->db->get('produk');
return $result;
}
function simpan($produk_nama,$produk_harga){
$data = array(
'produk_nama' => $produk_nama,
'produk_harga' => $produk_harga);
$this->db->insert('produk',$data);
}
function delete($produk_id){
$this->db->where('produk_id', $produk_id);
$this->db->delete('produk');
}
function get_produk_id($produk_id){
$query = $this->db->get_where('produk', array('produk_id' =>
$produk_id));
return $query;
}
function update($produk_id,$produk_nama,$produk_harga){
$data = array(
'produk_nama' => $produk_nama,
'produk_harga' => $product_harga
);
$this->db->where('produk_id', $produk_id);
$this->db->update('produk', $data);
}
}