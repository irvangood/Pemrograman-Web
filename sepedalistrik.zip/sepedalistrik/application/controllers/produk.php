<?php
class Produk extends CI_Controller{
function __construct(){
parent::__construct();
$this->load->model('produk_model');
}
function index(){
$data['produk'] = $this->produk_model->get_produk();
$this->load->view('produk_view',$data);
}
function tambah_produk(){
$this->load->view('tambah_produk_view');
}
function simpan(){
$produk_nama = $this->input->post('produk_nama');
$produk_harga = $this->input->post('produk_harga');
$this->produk_model->simpan($produk_nama,$produk_harga);
redirect('produk');
}
function delete(){
$produk_id = $this->uri->segment(3);
$this->produk_model->delete($produk_id);
redirect('produk');
}
function get_edit(){
$produk_id = $this->uri->segment(3);
$result = $this->produk_model->get_produk_id($produk_id);
if($result->num_rows() > 0){
$i = $result->row_array();
$data = array(
'produk_id' => $i['produk_id'],
'produk_nama' => $i['produk_nama'],
'produk_harga' => $i['produk_harga']
);
$this->load->view('edit_produk_view',$data);
}else{
echo "Data Tidak Ditemukan";
}
function update(){
$produk_id = $this->input->post('produk_id');
$produk_nama = $this->input->post('produk_nama');
$produk_harga = $this->input->post('produk_harga');
$this->produk_model->update($produk_id,$produk_nama,$produk_harga);
redirect('produk');}
}
}