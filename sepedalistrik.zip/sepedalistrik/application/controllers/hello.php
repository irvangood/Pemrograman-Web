<?php
class Hello extends CI_Controller{
function index(){
echo "Hello World";
}
function show(){
echo "I Make The World Better Place.";
}
}