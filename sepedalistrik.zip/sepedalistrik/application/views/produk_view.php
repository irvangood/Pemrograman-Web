<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Daftar Produk</title>
<!-- load bootstrap css file -->
<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
rel="stylesheet">
</head>
<body>
<div class="container">
<h1><center>Daftar Produk</center></h1>
<table class="table table-striped">
<thead>
<tr>
<th scope="col">#</th>
<th scope="col">Nama</th>
<th scope="col">Harga</th>
<th width="200">Action</th>
</tr>
</thead>
<?php
$count = 0;
foreach ($produk->result() as $row) :
$count++;?>
<tr>
<th scope="row"><?php echo $count;?></th>
<td><?php echo $row->produk_nama;?></td>
<td><?php echo number_format($row->produk_harga);?></td>
<td>
<a href="<?php echo 
site_url('produk/get_edit/'.$row->produk_id);?>" class="btn btn-sm btn-info">Update</a>
<a href="<?php echo 
site_url('produk/delete/'.$row->produk_id);?>" class="btn btn-sm btn-danger">Delete</a>
<td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
<!-- load jquery js file -->
<script src="<?php echo
base_url('assets/js/jquery.min.js');?>"></script>
<!-- load bootstrap js file -->
<script src="<?php echo
base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>