<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Edit Produk</title>
<!-- load bootstrap css file -->
<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
rel="stylesheet">
</head>
<body>
<div class="container">
<h1><center>Edit Produk</center></h1>
<div class="col-md-6 offset-md-3">
<form action="<?php echo site_url('produk/update');?>"
method="post">
<div class="form-group"><label>Nama</label>
<input type="text" class="form-control" nama="produk_nama"
value="<?php echo $produk_nama;?>" placeholder="Produk Nama">
</div>
<div class="form-group">
<label>Harga</label>
<input type="text" class="form-control" name="produk_harga"
value="<?php echo $produk_harga;?>" placeholder="Harga">
</div>
<input type="hidden" name="produk_id" value="<?php echo
$produk_id?>">
<button type="submit" class="btn btn-primary">Update</button>
</form>
</div>
</div>
<!-- load jquery js file -->
<script src="<?php echo
base_url('assets/js/jquery.min.js');?>"></script>
<!-- load bootstrap js file -->
<script src="<?php echo
base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>