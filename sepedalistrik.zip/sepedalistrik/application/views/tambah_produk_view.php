<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Tambah Produk Baru</title>
<!-- load bootstrap css file -->
<link href="<?php echo base_url('assets/css/bootstrap.min.css');?>"
 rel="stylesheet">
</head>
<body>
<div class="container">
<h1><center>Tambah Produk Baru</center></h1>
<div class="col-md-6 offset-md-3">
<form action="<?php echo site_url('produk/simpan');?>"
method="post">
<div class="form-group">
<label>Nama</label>
<input type="text" class="form-control" name="produk_nama"
placeholder="Nama">
</div>
<div class="form-group">
<label>Harga</label>
<input type="text" class="form-control" name="produk_harga"
placeholder="Harga">
</div>
<button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
<!-- load jquery js file -->
<script src="<?php echo
base_url('assets/js/jquery.min.js');?>"></script>
<!-- load bootstrap js file --><script src="<?php echo
base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>